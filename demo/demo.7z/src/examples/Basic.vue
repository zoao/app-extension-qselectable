<template>
  <div>
    <q-selectable
      v-model="selected"
      val="Image1"
    >
      <div class="q-pa-md fit">
        This is the "default" slot content
      </div>
    </q-selectable>
  </div>
</template>

<script>
export default {
  data () {
    return {
      selected: null
    }
  }
}
</script>
