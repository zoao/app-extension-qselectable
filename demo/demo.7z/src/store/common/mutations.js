export const toc = (state, toc) => {
  state.toc = toc
}
