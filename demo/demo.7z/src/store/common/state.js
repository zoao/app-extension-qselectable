export default {
  toc: []
}
