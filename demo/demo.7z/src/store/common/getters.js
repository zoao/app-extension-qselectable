export const toc = (state) => state.toc
